/**
 * @param {string | HTMLElement} target
 * @param {import('./types.js').PlayerOptions} options
 * @returns {import('./types.js').UepPlayer}
 */
export declare function createPlayer(target: string | HTMLElement, options: import('./types.js').PlayerOptions): import('./types.js').UepPlayer;
//# sourceMappingURL=controller.d.ts.map