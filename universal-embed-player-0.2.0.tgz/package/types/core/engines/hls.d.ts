export declare function createHlsEngine(container: any, resolvedSource: any, options: any, emitter: any): Promise<{
    mediaElement: any;
    controllable: boolean;
    play: () => void;
    pause: () => any;
    seekTo: (seconds: any) => void;
    setVolume: (volume: any) => void;
    setPlaybackRate: (rate: any) => void;
    destroy: () => void;
}>;
//# sourceMappingURL=hls.d.ts.map