export declare const KALTURA_PROTOCOL: {
    createElement(resolvedSource: any): HTMLDivElement;
    attach(container: any, emitter: any, options: any, resolvedSource: any): Promise<any>;
};
//# sourceMappingURL=kaltura.d.ts.map