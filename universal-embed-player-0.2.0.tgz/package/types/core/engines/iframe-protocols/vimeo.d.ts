export declare const VIMEO_PROTOCOL: {
    buildSrc(embedUrl: any): any;
    /**
     * @param {HTMLIFrameElement} iframe
     * @param {import('../events.js').UnifiedEventEmitter} emitter
     * @param {import('../../types.js').PlayerOptions} options
     */
    attach(iframe: HTMLIFrameElement, emitter: import('../events.js').UnifiedEventEmitter, options: import('../../types.js').PlayerOptions): Promise<{
        play: () => any;
        pause: () => any;
        seekTo: (seconds: any) => any;
        setVolume: (volume: any) => any;
        setPlaybackRate: (rate: any) => any;
        destroy: () => any;
    }>;
};
//# sourceMappingURL=vimeo.d.ts.map