export declare const WISTIA_PROTOCOL: {
    createElement(resolvedSource: any): HTMLDivElement;
    /**
     * @param {HTMLDivElement} container
     * @param {import('../events.js').UnifiedEventEmitter} emitter
     * @param {import('../../types.js').PlayerOptions} options
     */
    attach(container: HTMLDivElement, emitter: import('../events.js').UnifiedEventEmitter, options: import('../../types.js').PlayerOptions): Promise<{
        play: () => void;
        pause: () => void;
        seekTo: (seconds: any) => void;
        setVolume: (volume: any) => void;
        setPlaybackRate: (rate: any) => void;
        destroy: () => void;
    }>;
};
//# sourceMappingURL=wistia.d.ts.map