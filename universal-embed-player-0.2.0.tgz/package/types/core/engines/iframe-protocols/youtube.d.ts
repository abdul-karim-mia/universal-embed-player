export declare const YOUTUBE_PROTOCOL: {
    buildSrc(embedUrl: any, origin: any): string;
    /**
     * @param {HTMLIFrameElement} iframe
     * @param {import('../events.js').UnifiedEventEmitter} emitter
     * @param {import('../../types.js').PlayerOptions} options
     */
    attach(iframe: HTMLIFrameElement, emitter: import('../events.js').UnifiedEventEmitter, options: import('../../types.js').PlayerOptions): Promise<any>;
};
//# sourceMappingURL=youtube.d.ts.map