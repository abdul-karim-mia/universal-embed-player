export declare function createIframeEngine(container: any, resolvedSource: any, options: any, emitter: any): Promise<{
    mediaElement: any;
    controllable: boolean;
    play: any;
    pause: any;
    seekTo: any;
    setVolume: any;
    setPlaybackRate: any;
    destroy: () => void;
}>;
//# sourceMappingURL=iframe.d.ts.map