export declare function applyMediaOptions(video: any, options: any): void;
/** @returns {() => void} cleanup function that removes all bound listeners */
export declare function attachMediaElementEvents(video: any, emitter: any, provider: any, options: any): () => void;
export declare function createMediaControls(video: any, emitter: any, provider: any): {
    mediaElement: any;
    controllable: boolean;
    play: () => void;
    pause: () => any;
    seekTo: (seconds: any) => void;
    setVolume: (volume: any) => void;
    setPlaybackRate: (rate: any) => void;
};
//# sourceMappingURL=media-events.d.ts.map