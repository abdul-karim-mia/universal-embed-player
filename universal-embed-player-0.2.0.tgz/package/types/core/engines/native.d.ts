export declare function createNativeEngine(container: any, resolvedSource: any, options: any, emitter: any): {
    mediaElement: any;
    controllable: boolean;
    play: () => void;
    pause: () => any;
    seekTo: (seconds: any) => void;
    setVolume: (volume: any) => void;
    setPlaybackRate: (rate: any) => void;
    destroy: () => void;
};
//# sourceMappingURL=native.d.ts.map