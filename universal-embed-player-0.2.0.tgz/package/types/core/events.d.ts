export declare class UnifiedEventEmitter {
    #private;
    on(type: any, handler: any): () => void;
    off(type: any, handler: any): void;
    emit(type: any, payload?: {}): {
        type: any;
    };
    removeAllListeners(): void;
}
//# sourceMappingURL=events.d.ts.map