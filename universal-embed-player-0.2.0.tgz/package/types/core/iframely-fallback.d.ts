/**
 * @param {string} url
 * @param {string} key
 * @returns {Promise<import('./types.js').ResolvedSource | null>}
 */
export declare function resolveViaIframely(url: string, key: string): Promise<import('./types.js').ResolvedSource | null>;
//# sourceMappingURL=iframely-fallback.d.ts.map