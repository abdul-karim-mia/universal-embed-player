export declare function posterUrlFor(resolved: any, targetWidth?: number): any;
export declare function asyncPosterUrlFor(resolved: any, targetWidth?: number): any;
export declare function createLightPoster(container: any, resolved: any, options: any, onActivate: any): {
    destroy: () => void;
};
//# sourceMappingURL=lazy.d.ts.map