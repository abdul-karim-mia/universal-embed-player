/**
 * @param {import('./types.js').ResolvedSource | null} resolved
 * @param {string} url - original input URL, used as a last-resort contentUrl/embedUrl
 * @param {import('./types.js').SeoMetadata} [seo]
 * @returns {Record<string, unknown> | null} null when `seo.name` is missing — nothing worth emitting
 */
export declare function buildVideoObjectJsonLd(resolved: import('./types.js').ResolvedSource | null, url: string, seo?: import('./types.js').SeoMetadata): Record<string, unknown> | null;
export declare function stringifyForScriptTag(value: any): string;
//# sourceMappingURL=seo.d.ts.map