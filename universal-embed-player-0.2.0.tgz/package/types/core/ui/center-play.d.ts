export declare function createCenterPlayButton(container: any, engine: any, emitter: any, options: any): {
    destroy: () => void;
};
//# sourceMappingURL=center-play.d.ts.map