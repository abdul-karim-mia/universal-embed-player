export declare function createControls(container: any, engine: any, emitter: any, options: any): {
    /** Returns true if the control bar is currently in the muted state. */
    getMuteState: () => boolean;
    /** Sync mute icon when mute state is changed via the player API. */
    setMuted: (muted: any) => void;
    destroy: () => void;
};
//# sourceMappingURL=controls.d.ts.map