export declare function createShield(container: any, engine: any): {
    setPlaying: (playing: any) => void;
    destroy: () => void;
};
//# sourceMappingURL=shield.d.ts.map