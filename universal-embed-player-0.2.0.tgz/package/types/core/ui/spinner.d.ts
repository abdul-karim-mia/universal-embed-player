export declare function createSpinner(container: any, emitter: any): {
    show: () => void;
    hide: () => void;
    destroy: () => void;
};
//# sourceMappingURL=spinner.d.ts.map