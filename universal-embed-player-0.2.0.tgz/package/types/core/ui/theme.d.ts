export declare function applyTheme(container: any, theme?: {}): void;
//# sourceMappingURL=theme.d.ts.map