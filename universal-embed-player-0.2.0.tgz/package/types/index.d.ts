export { createPlayer } from './core/controller.js';
export { resolveSource, RESOLVERS } from './resolvers/index.js';
//# sourceMappingURL=index.d.ts.map