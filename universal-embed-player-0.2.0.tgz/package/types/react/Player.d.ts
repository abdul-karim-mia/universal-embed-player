export type PlayerProps = import('../core/types.js').PlayerOptions & {
    className?: string;
    style?: import('react').CSSProperties;
};
/**
 * @typedef {import('../core/types.js').PlayerOptions & {
 *   className?: string,
 *   style?: import('react').CSSProperties,
 * }} PlayerProps
 */
/**
 * @param {PlayerProps} props
 * @returns {import('react').ReactElement}
 */
export declare function Player(props: PlayerProps): import('react').ReactElement;
//# sourceMappingURL=Player.d.ts.map