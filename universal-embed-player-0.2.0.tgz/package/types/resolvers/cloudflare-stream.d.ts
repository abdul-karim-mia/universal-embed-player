export declare function resolve(url: any): {
    provider: string;
    type: string;
    id: any;
    src: string;
    stability: string;
    embedUrl?: undefined;
} | {
    src?: undefined;
    provider: string;
    type: string;
    id: any;
    embedUrl: string;
    stability: string;
};
//# sourceMappingURL=cloudflare-stream.d.ts.map