import { resolve as youtube } from './youtube.js';
import { resolve as cloudflareStream } from './cloudflare-stream.js';
import { resolve as loom } from './loom.js';
export declare const RESOLVERS: (typeof youtube | typeof cloudflareStream | typeof loom)[];
export declare function resolveSource(url: any): import("../core/types.js").ResolvedSource | {
    provider: string;
    type: string;
    id: any;
    src: string;
    stability: string;
    embedUrl?: undefined;
} | {
    provider: string;
    type: string;
    id: any;
    embedUrl: string;
    stability: string;
};
//# sourceMappingURL=index.d.ts.map