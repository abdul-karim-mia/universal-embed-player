export declare function resolve(url: any): {
    provider: string;
    type: string;
    id: any;
    embedUrl: string;
    stability: string;
};
//# sourceMappingURL=panopto.d.ts.map