export declare function resolve(url: any): {
    provider: string;
    type: string;
    id: any;
    embedUrl: string;
    stability: string;
};
//# sourceMappingURL=screenpal.d.ts.map