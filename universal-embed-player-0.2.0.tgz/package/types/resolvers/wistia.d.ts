/**
 * @param {string} url
 * @returns {import('../core/types.js').ResolvedSource | null}
 */
export declare function resolve(url: string): import('../core/types.js').ResolvedSource | null;
//# sourceMappingURL=wistia.d.ts.map