/**
 * @param {string} url
 * @returns {import('../core/types.js').ResolvedSource | null}
 */
export declare function resolve(url: string): import('../core/types.js').ResolvedSource | null;
//# sourceMappingURL=youtube.d.ts.map