export declare const Player: import("vue").DefineComponent<import("vue").ExtractPropTypes<{
    url: {
        type: StringConstructor;
        required: true;
    };
    controls: {
        type: BooleanConstructor;
        default: boolean;
    };
    light: {
        type: BooleanConstructor;
        default: boolean;
    };
    poster: {
        type: StringConstructor;
        default: any;
    };
    autoplay: {
        type: BooleanConstructor;
        default: boolean;
    };
    muted: {
        type: BooleanConstructor;
        default: boolean;
    };
    loop: {
        type: BooleanConstructor;
        default: boolean;
    };
    playbackRates: {
        type: ArrayConstructor;
        default: any;
    };
    volume: {
        type: NumberConstructor;
        default: any;
    };
    volumeKey: {
        type: StringConstructor;
        default: any;
    };
    videoSize: {
        type: StringConstructor;
        default: string;
    };
    centerPlayButton: {
        type: BooleanConstructor;
        default: boolean;
    };
    theme: {
        type: ObjectConstructor;
        default: any;
    };
    shield: {
        type: BooleanConstructor;
        default: boolean;
    };
    seo: {
        type: ObjectConstructor;
        default: any;
    };
}>, () => import("vue").VNode<import("vue").RendererNode, import("vue").RendererElement, {
    [key: string]: any;
}>, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, "event"[], "event", import("vue").PublicProps, Readonly<import("vue").ExtractPropTypes<{
    url: {
        type: StringConstructor;
        required: true;
    };
    controls: {
        type: BooleanConstructor;
        default: boolean;
    };
    light: {
        type: BooleanConstructor;
        default: boolean;
    };
    poster: {
        type: StringConstructor;
        default: any;
    };
    autoplay: {
        type: BooleanConstructor;
        default: boolean;
    };
    muted: {
        type: BooleanConstructor;
        default: boolean;
    };
    loop: {
        type: BooleanConstructor;
        default: boolean;
    };
    playbackRates: {
        type: ArrayConstructor;
        default: any;
    };
    volume: {
        type: NumberConstructor;
        default: any;
    };
    volumeKey: {
        type: StringConstructor;
        default: any;
    };
    videoSize: {
        type: StringConstructor;
        default: string;
    };
    centerPlayButton: {
        type: BooleanConstructor;
        default: boolean;
    };
    theme: {
        type: ObjectConstructor;
        default: any;
    };
    shield: {
        type: BooleanConstructor;
        default: boolean;
    };
    seo: {
        type: ObjectConstructor;
        default: any;
    };
}>> & Readonly<{
    onEvent?: (...args: any[]) => any;
}>, {
    controls: boolean;
    light: boolean;
    poster: string;
    autoplay: boolean;
    muted: boolean;
    loop: boolean;
    playbackRates: unknown[];
    volume: number;
    volumeKey: string;
    videoSize: string;
    centerPlayButton: boolean;
    theme: Record<string, any>;
    shield: boolean;
    seo: Record<string, any>;
}, {}, {}, {}, string, import("vue").ComponentProvideOptions, true, {}, any>;
//# sourceMappingURL=Player.d.ts.map