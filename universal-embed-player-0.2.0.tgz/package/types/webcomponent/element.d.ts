declare const BaseElement: {
    new (): {};
};
export declare class UepPlayerElement extends BaseElement {
    #private;
    innerHTML: string;
    static get observedAttributes(): string[];
    constructor();
    /** @returns {string | undefined} */
    get url(): string | undefined;
    /** @param {string} value */
    set url(value: string);
    /** @returns {boolean} */
    get controls(): boolean;
    /** @param {boolean} value */
    set controls(value: boolean);
    /** @returns {boolean} */
    get light(): boolean;
    /** @param {boolean} value */
    set light(value: boolean);
    /** @returns {string | undefined} */
    get poster(): string | undefined;
    /** @param {string} value */
    set poster(value: string);
    /** @returns {boolean} */
    get autoplay(): boolean;
    /** @param {boolean} value */
    set autoplay(value: boolean);
    /** @returns {boolean} */
    get muted(): boolean;
    /** @param {boolean} value */
    set muted(value: boolean);
    /** @returns {boolean} */
    get loop(): boolean;
    /** @param {boolean} value */
    set loop(value: boolean);
    /** @returns {number | undefined} */
    get volume(): number | undefined;
    /** @param {number} value */
    set volume(value: number);
    /** @returns {string | undefined} */
    get volumeKey(): string | undefined;
    /** @param {string} value */
    set volumeKey(value: string);
    /** @returns {'cover' | 'contain' | 'fill'} */
    get videoSize(): 'cover' | 'contain' | 'fill';
    /** @param {'cover' | 'contain' | 'fill'} value */
    set videoSize(value: 'cover' | 'contain' | 'fill');
    /** @returns {boolean} */
    get centerPlayButton(): boolean;
    /** @param {boolean} value */
    set centerPlayButton(value: boolean);
    /** @returns {boolean} */
    get loadingSpinner(): boolean;
    /** @param {boolean} value */
    set loadingSpinner(value: boolean);
    /** @returns {boolean} */
    get shield(): boolean;
    /** @param {boolean} value */
    set shield(value: boolean);
    /** @returns {string | undefined} */
    get iframelyKey(): string | undefined;
    /** @param {string} value */
    set iframelyKey(value: string);
    /** @returns {import('../core/types.js').PlayerTheme | undefined} */
    get theme(): import('../core/types.js').PlayerTheme | undefined;
    /** @param {import('../core/types.js').PlayerTheme} value */
    set theme(value: import('../core/types.js').PlayerTheme);
    /** @returns {import('../core/types.js').SeoMetadata | undefined} */
    get seo(): import('../core/types.js').SeoMetadata | undefined;
    /** @param {import('../core/types.js').SeoMetadata} value */
    set seo(value: import('../core/types.js').SeoMetadata);
    /** @returns {number[] | undefined} */
    get playbackRates(): number[] | undefined;
    /** @param {number[]} value */
    set playbackRates(value: number[]);
    /**
     * Callback fired for every unified event type — no attribute equivalent
     * (functions don't serialize). Same events are also dispatched as
     * `uep-<type>` CustomEvents (and a catch-all `uep-event`) on the element.
     * @returns {((event: import('../core/types.js').UnifiedPlayerEvent) => void) | undefined}
     */
    get onEvent(): ((event: import('../core/types.js').UnifiedPlayerEvent) => void) | undefined;
    /** @param {(event: import('../core/types.js').UnifiedPlayerEvent) => void} fn */
    set onEvent(fn: (event: import('../core/types.js').UnifiedPlayerEvent) => void);
    connectedCallback(): void;
    disconnectedCallback(): void;
    /**
     * @param {string} name
     * @param {string | null} oldValue
     * @param {string | null} newValue
     */
    attributeChangedCallback(name: string, oldValue: string | null, newValue: string | null): void;
    play(): void;
    pause(): void;
    /** @param {number} seconds */
    seekTo(seconds: number): void;
    /** @param {number} volume */
    setVolume(volume: number): void;
    /** @param {number} rate */
    setPlaybackRate(rate: number): void;
    /** @param {'cover' | 'contain' | 'fill'} size */
    setVideoSize(size: 'cover' | 'contain' | 'fill'): void;
    mute(): void;
    unmute(): void;
    toggleMute(): void;
    /**
     * @param {string} type
     * @param {(event: import('../core/types.js').UnifiedPlayerEvent) => void} handler
     * @returns {() => void}
     */
    on(type: string, handler: (event: import('../core/types.js').UnifiedPlayerEvent) => void): () => void;
    /**
     * @param {string} type
     * @param {(event: import('../core/types.js').UnifiedPlayerEvent) => void} handler
     */
    off(type: string, handler: (event: import('../core/types.js').UnifiedPlayerEvent) => void): void;
    /** @returns {Promise<void>} */
    get ready(): Promise<void>;
}
export declare const WEBCOMPONENT_EVENT_TYPES: string[];
export {};
//# sourceMappingURL=element.d.ts.map